﻿namespace Gym_Aplication
{
    internal class ScheduleEntry
    {
        public string Time { get; set; }
        public string Activity { get; set; }
        public string Trainer { get; set; }
        public string Room { get; set; }
    }
}
